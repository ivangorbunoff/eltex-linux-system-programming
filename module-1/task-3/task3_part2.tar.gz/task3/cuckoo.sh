#!/bin/bash

fifo="${1#--pishitesuda=}"
log="cuckoo.log"

mkfifo "$fifo" || exit 1

echo "$(date '+%F %T') Startup!" >> "$log"

shutdown() {
    echo "$(date '+%F %T') Shutdown!" >> "$log"
    rm -f "$fifo"
    exit 0
}

trap shutdown SIGTERM SIGINT

exec 3<>"$fifo"

while read -r request <&3; do
    if [[ "$request" =~ ^([^[]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
        name="${BASH_REMATCH[1]}"
        pid="${BASH_REMATCH[2]}"

        n=$((RANDOM % 9 + 2))

        echo "$(date '+%F %T') $name[$pid] $n" >> "$log"
        echo "$n" > "${fifo}.${pid}"
    fi
done
