#!/bin/bash

cd /root/task3 || exit 1

while read -r script; do
    found=0

    for proc in /proc/[0-9]*; do

        if [[ "$proc/exe" -ef /bin/bash ]] &&
            grep -zFxq "$script" "$proc/cmdline" 2>/dev/null; then
            found=1
            break
        fi
    done

    if [ "$found" -eq 0 ]; then
        nohup "$script" > /dev/null 2>&1 &

        echo "$(date '+%F %T') Restarted $script PID $!" >> observer.log
    fi

done < observer.conf
