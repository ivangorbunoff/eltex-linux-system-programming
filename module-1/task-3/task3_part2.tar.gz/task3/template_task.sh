#!/bin/bash

name="${0##*/}"

if [[ "$name" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

log="report_${name}.log"
echo "$(date '+%F %T') [$$] Скрипт запущен" >> "$log"

pid=$(systemctl show -p MainPID --value cuckoo.service)

fifo=$(tr '\0' '\n' < "/proc/$pid/cmdline" | sed -n 's/^--pishitesuda=//p')

if [[ ! -p "$fifo" ]]; then
    echo "Канал cuckoo не найден"
    exit 1
fi

reply="${fifo}.$$"
mkfifo "$reply"

echo "${name}[$$]: how much time do I have?" > "$fifo"

read -r n < "$reply"
rm "$reply"

sleep "$n"

echo "$(date '+%F %T') [$$] Скрипт завершился, работал $n секунд." >> "$log"
